package com.example.drugidomaci.model;

public enum Lenght {
     centimeter,
    feet,
    inch,
    kilometer,
    league,
    meter,
    microinch,
    mile,
    milimeter,
    yard;
    public double value(){
        switch (this){
            case centimeter:return 1;
            case feet: return 0.03280839895;
            case inch: return 0.3937007874;
            case kilometer:return 0.00001;
            case league:return 0.0000020712331461;
            case meter: return 0.01;
            case microinch: return 393700.7874;
            case mile: return  0.0000062137119224;
            case milimeter: return 10;
            case yard: return  0.010936132983;
        }
        return 0;
    }

}

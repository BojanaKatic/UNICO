package com.example.drugidomaci.model;

public enum Temperature {
    Celsius,
    Fahrenheit,
    Kelvin;


}
